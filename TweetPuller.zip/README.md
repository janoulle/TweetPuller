##TweetPuller
My first Chrome extension. TweetPuller is a simple tool to pull in first 10 tweets for a given twitter user.

##Problems?
Tweet me (@janetalkstech) with any problems. This is very much a learning experience so bear with me. :)