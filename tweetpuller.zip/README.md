My first Chrome extension!
Simple tool to pull in first 20 tweets.