##TweetPuller
My first Chrome extension is available on the Chrome Webstore here: http://bit.ly/tweetpuller. <a href="http://bit.ly/tweetpuller" title="TweetPuller by Jane Ullah">TweetPuller</a> is a simple tool to pull in first 10 tweets for a given twitter user. Currently at version 0.3, you can now view several tweets from different users in the same session and use the options pages to set a saved username. The program should also give you helpful messages when you try to view a proected user's page or a nonexistent user's page. 

##TODO:
Allow users to authenticate in order to view protected tweets.
Caching tweets to prevent accidentally hitting the rate limit.

##Problems?
Tweet me (@janetalkstech) with any problems. This is very much a learning experience so bear with me. :)